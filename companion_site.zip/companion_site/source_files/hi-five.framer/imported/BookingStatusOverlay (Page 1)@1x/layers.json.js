window.__imported__ = window.__imported__ || {};
window.__imported__['BookingStatusOverlay (Page 1)@1x/layers.json.js'] = [
   {
      "objectId" : "4",
      "name" : "BookingStatusOverlay",
      "visible" : true,
      "maskFrame" : {
         "x" : 1027,
         "y" : 2285,
         "width" : 906,
         "height" : 534
      },
      "layerFrame" : {
         "x" : 1027,
         "y" : 2285,
         "width" : 906,
         "height" : 534
      },
      "children" : [
         {
            "objectId" : "3",
            "name" : "layer-1",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 0,
               "y" : 0,
               "width" : 906,
               "height" : 534
            },
            "children" : [
               {
                  "objectId" : "2",
                  "name" : "Text",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 17,
                     "width" : 906,
                     "height" : 491
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/2.png",
                     "frame" : {
                        "x" : 0,
                        "y" : 17,
                        "width" : 906,
                        "height" : 491
                     }
                  }
               },
               {
                  "objectId" : "1",
                  "name" : "ViewMore",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 671,
                     "y" : 441,
                     "width" : 183,
                     "height" : 69
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/1.png",
                     "frame" : {
                        "x" : 671,
                        "y" : 441,
                        "width" : 183,
                        "height" : 69
                     }
                  }
               },
               {
                  "objectId" : "0",
                  "name" : "layer-1_BG",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 0,
                     "width" : 906,
                     "height" : 534
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/0.png",
                     "frame" : {
                        "x" : 0,
                        "y" : 0,
                        "width" : 906,
                        "height" : 534
                     }
                  }
               }
            ],
            "kind" : "group"
         }
      ],
      "kind" : "artboard",
      "backgroundColor" : "rgba(0.00000, 0.00000, 0.00000, 1.00000)"
   }
];
