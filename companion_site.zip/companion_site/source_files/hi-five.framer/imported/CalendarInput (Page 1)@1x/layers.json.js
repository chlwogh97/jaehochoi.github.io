window.__imported__ = window.__imported__ || {};
window.__imported__['CalendarInput (Page 1)@1x/layers.json.js'] = [
   {
      "objectId" : "16",
      "name" : "Calendar",
      "visible" : true,
      "maskFrame" : null,
      "layerFrame" : {
         "x" : 673,
         "y" : 461,
         "width" : 371,
         "height" : 408
      },
      "children" : [
         {
            "objectId" : "15",
            "name" : "Header",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 0,
               "y" : 0,
               "width" : 363,
               "height" : 80
            },
            "children" : [
               {
                  "objectId" : "14",
                  "name" : "ToRight",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 330,
                     "y" : 16,
                     "width" : 13,
                     "height" : 20
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/14.png",
                     "frame" : {
                        "x" : 330,
                        "y" : 16,
                        "width" : 13,
                        "height" : 20
                     }
                  }
               },
               {
                  "objectId" : "13",
                  "name" : "ToLeft",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 21,
                     "y" : 16,
                     "width" : 13,
                     "height" : 20
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/13.png",
                     "frame" : {
                        "x" : 21,
                        "y" : 16,
                        "width" : 13,
                        "height" : 20
                     }
                  }
               },
               {
                  "objectId" : "12",
                  "name" : "Month_Year",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 99,
                     "y" : 15,
                     "width" : 133,
                     "height" : 26
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/12.png",
                     "frame" : {
                        "x" : 99,
                        "y" : 15,
                        "width" : 133,
                        "height" : 26
                     }
                  }
               },
               {
                  "objectId" : "11",
                  "name" : "Days",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 16,
                     "y" : 58,
                     "width" : 329,
                     "height" : 17
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/11.png",
                     "frame" : {
                        "x" : 16,
                        "y" : 58,
                        "width" : 329,
                        "height" : 17
                     }
                  }
               },
               {
                  "objectId" : "10",
                  "name" : "HeaderBG",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 0,
                     "width" : 363,
                     "height" : 80
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/10.png",
                     "frame" : {
                        "x" : 0,
                        "y" : 0,
                        "width" : 363,
                        "height" : 80
                     }
                  }
               }
            ],
            "kind" : "group"
         },
         {
            "objectId" : "9",
            "name" : "Dates",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 18,
               "y" : 71,
               "width" : 327,
               "height" : 306
            },
            "children" : [
               {
                  "objectId" : "8",
                  "name" : "SatCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 324,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/8.png",
                     "frame" : {
                        "x" : 324,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "7",
                  "name" : "FriCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 273,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/7.png",
                     "frame" : {
                        "x" : 273,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "6",
                  "name" : "ThuCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 222,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/6.png",
                     "frame" : {
                        "x" : 222,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "5",
                  "name" : "WedCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 171,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/5.png",
                     "frame" : {
                        "x" : 171,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "4",
                  "name" : "TueCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 120,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/4.png",
                     "frame" : {
                        "x" : 120,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "3",
                  "name" : "MonCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 69,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/3.png",
                     "frame" : {
                        "x" : 69,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "2",
                  "name" : "SunCol",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 18,
                     "y" : 71,
                     "width" : 21,
                     "height" : 306
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/2.png",
                     "frame" : {
                        "x" : 18,
                        "y" : 71,
                        "width" : 21,
                        "height" : 306
                     }
                  }
               },
               {
                  "objectId" : "1",
                  "name" : "SelectDate",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 109,
                     "y" : 243,
                     "width" : 44,
                     "height" : 44
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/1.png",
                     "frame" : {
                        "x" : 109,
                        "y" : 243,
                        "width" : 44,
                        "height" : 44
                     }
                  }
               }
            ],
            "kind" : "group"
         },
         {
            "objectId" : "0",
            "name" : "CalendarBG",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : -4,
               "y" : -2,
               "width" : 371,
               "height" : 408
            },
            "children" : [],
            "kind" : "group",
            "imageType" : "png",
            "image" : {
               "path" : "images/0.png",
               "frame" : {
                  "x" : -4,
                  "y" : -2,
                  "width" : 371,
                  "height" : 408
               }
            }
         }
      ],
      "kind" : "artboard",
      "backgroundColor" : "rgba(1.00000, 1.00000, 1.00000, 1.00000)"
   }
];
