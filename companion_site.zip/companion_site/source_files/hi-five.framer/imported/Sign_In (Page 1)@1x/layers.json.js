window.__imported__ = window.__imported__ || {};
window.__imported__['Sign_In (Page 1)@1x/layers.json.js'] = [
   {
      "objectId" : "13",
      "name" : "Sign_In",
      "visible" : true,
      "maskFrame" : {
         "x" : -720,
         "y" : -500,
         "width" : 1440,
         "height" : 1024
      },
      "layerFrame" : {
         "x" : -720,
         "y" : -500,
         "width" : 1440,
         "height" : 1024
      },
      "children" : [
         {
            "objectId" : "12",
            "name" : "Content",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 450,
               "y" : 82,
               "width" : 540,
               "height" : 860
            },
            "children" : [
               {
                  "objectId" : "11",
                  "name" : "Staff_ID",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 450,
                     "y" : 352,
                     "width" : 540,
                     "height" : 90
                  },
                  "children" : [
                     {
                        "objectId" : "10",
                        "name" : "Input",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 450,
                           "y" : 393,
                           "width" : 540,
                           "height" : 49
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/10.png",
                           "frame" : {
                              "x" : 450,
                              "y" : 393,
                              "width" : 540,
                              "height" : 49
                           }
                        }
                     }
                  ],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/11.png",
                     "frame" : {
                        "x" : 450,
                        "y" : 352,
                        "width" : 540,
                        "height" : 90
                     }
                  }
               },
               {
                  "objectId" : "9",
                  "name" : "Password",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 450,
                     "y" : 492,
                     "width" : 540,
                     "height" : 90
                  },
                  "children" : [
                     {
                        "objectId" : "8",
                        "name" : "pw_input",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 450,
                           "y" : 533,
                           "width" : 540,
                           "height" : 49
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/8.png",
                           "frame" : {
                              "x" : 450,
                              "y" : 533,
                              "width" : 540,
                              "height" : 49
                           }
                        }
                     }
                  ],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/9.png",
                     "frame" : {
                        "x" : 450,
                        "y" : 492,
                        "width" : 540,
                        "height" : 90
                     }
                  }
               },
               {
                  "objectId" : "7",
                  "name" : "Remember_Me",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 567,
                     "y" : 632,
                     "width" : 306,
                     "height" : 50
                  },
                  "children" : [
                     {
                        "objectId" : "6",
                        "name" : "X_Check",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 833,
                           "y" : 643,
                           "width" : 29,
                           "height" : 29
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/6.png",
                           "frame" : {
                              "x" : 833,
                              "y" : 643,
                              "width" : 29,
                              "height" : 29
                           }
                        }
                     },
                     {
                        "objectId" : "5",
                        "name" : "Checkbox_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 832,
                           "y" : 641,
                           "width" : 32,
                           "height" : 32
                        },
                        "children" : [
                           {
                              "objectId" : "4",
                              "name" : "Checkbox",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 832,
                                 "y" : 641,
                                 "width" : 32,
                                 "height" : 32
                              },
                              "children" : [],
                              "kind" : "group",
                              "imageType" : "png",
                              "image" : {
                                 "path" : "images/4.png",
                                 "frame" : {
                                    "x" : 832,
                                    "y" : 641,
                                    "width" : 32,
                                    "height" : 32
                                 }
                              }
                           }
                        ],
                        "kind" : "group"
                     }
                  ],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/7.png",
                     "frame" : {
                        "x" : 567,
                        "y" : 632,
                        "width" : 306,
                        "height" : 50
                     }
                  }
               },
               {
                  "objectId" : "3",
                  "name" : "Log_In",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 567,
                     "y" : 732,
                     "width" : 306,
                     "height" : 70
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/3.png",
                     "frame" : {
                        "x" : 567,
                        "y" : 732,
                        "width" : 306,
                        "height" : 70
                     }
                  }
               },
               {
                  "objectId" : "2",
                  "name" : "Forgot_Staff_ID",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 567,
                     "y" : 852,
                     "width" : 306,
                     "height" : 30
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/2.png",
                     "frame" : {
                        "x" : 567,
                        "y" : 852,
                        "width" : 306,
                        "height" : 30
                     }
                  }
               },
               {
                  "objectId" : "1",
                  "name" : "Forgot_Password",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 567,
                     "y" : 912,
                     "width" : 306,
                     "height" : 30
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/1.png",
                     "frame" : {
                        "x" : 567,
                        "y" : 912,
                        "width" : 306,
                        "height" : 30
                     }
                  }
               }
            ],
            "kind" : "group",
            "imageType" : "png",
            "image" : {
               "path" : "images/12.png",
               "frame" : {
                  "x" : 450,
                  "y" : 82,
                  "width" : 540,
                  "height" : 860
               }
            }
         },
         {
            "objectId" : "0",
            "name" : "Background",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 0,
               "y" : 0,
               "width" : 1440,
               "height" : 1024
            },
            "children" : [],
            "kind" : "group",
            "imageType" : "png",
            "image" : {
               "path" : "images/0.png",
               "frame" : {
                  "x" : 0,
                  "y" : 0,
                  "width" : 1440,
                  "height" : 1024
               }
            }
         }
      ],
      "kind" : "artboard",
      "backgroundColor" : "rgba(1.00000, 1.00000, 1.00000, 1.00000)"
   }
];
