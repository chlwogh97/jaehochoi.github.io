window.__imported__ = window.__imported__ || {};
window.__imported__['Contact Police (Page 1)@1x/layers.json.js'] = [
   {
      "objectId" : "47",
      "name" : "Contact_Police",
      "visible" : true,
      "maskFrame" : {
         "x" : 2240,
         "y" : 5850,
         "width" : 1440,
         "height" : 1024
      },
      "layerFrame" : {
         "x" : 2240,
         "y" : 5850,
         "width" : 1440,
         "height" : 1024
      },
      "children" : [
         {
            "objectId" : "46",
            "name" : "Nav_Side_Bar",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 0,
               "y" : 0,
               "width" : 250,
               "height" : 1024
            },
            "children" : [
               {
                  "objectId" : "45",
                  "name" : "Icons",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 20,
                     "y" : 236,
                     "width" : 210,
                     "height" : 489
                  },
                  "children" : [
                     {
                        "objectId" : "44",
                        "name" : "Notifications_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 206,
                           "y" : 236,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/44.png",
                           "frame" : {
                              "x" : 206,
                              "y" : 236,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "43",
                        "name" : "Home_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 305,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/43.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 305,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "42",
                        "name" : "Adjust_Bookings",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 359,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/42.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 359,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "41",
                        "name" : "Service_Robots",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 413,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/41.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 413,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "40",
                        "name" : "Contact_3",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 467,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/40.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 467,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "39",
                        "name" : "Infringements_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 647,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/39.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 647,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     },
                     {
                        "objectId" : "38",
                        "name" : "Settings_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 20,
                           "y" : 701,
                           "width" : 24,
                           "height" : 24
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/38.png",
                           "frame" : {
                              "x" : 20,
                              "y" : 701,
                              "width" : 24,
                              "height" : 24
                           }
                        }
                     }
                  ],
                  "kind" : "group"
               },
               {
                  "objectId" : "37",
                  "name" : "Options",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 290,
                     "width" : 230,
                     "height" : 453
                  },
                  "children" : [
                     {
                        "objectId" : "36",
                        "name" : "Home",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 290,
                           "width" : 230,
                           "height" : 57
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/36.png",
                           "frame" : {
                              "x" : 0,
                              "y" : 290,
                              "width" : 230,
                              "height" : 57
                           }
                        }
                     },
                     {
                        "objectId" : "35",
                        "name" : "AdjustBookings",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 359,
                           "width" : 230,
                           "height" : 42
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/35.png",
                           "frame" : {
                              "x" : 0,
                              "y" : 359,
                              "width" : 230,
                              "height" : 42
                           }
                        }
                     },
                     {
                        "objectId" : "34",
                        "name" : "ServiceRobots",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 413,
                           "width" : 230,
                           "height" : 42
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/34.png",
                           "frame" : {
                              "x" : 0,
                              "y" : 413,
                              "width" : 230,
                              "height" : 42
                           }
                        }
                     },
                     {
                        "objectId" : "33",
                        "name" : "Contact_2",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 467,
                           "width" : 230,
                           "height" : 167
                        },
                        "children" : [
                           {
                              "objectId" : "32",
                              "name" : "ContactTab",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 0,
                                 "y" : 468,
                                 "width" : 230,
                                 "height" : 40
                              },
                              "children" : [
                                 {
                                    "objectId" : "31",
                                    "name" : "ContactTabBorder",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 0,
                                       "y" : 505,
                                       "width" : 230,
                                       "height" : 3
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/31.png",
                                       "frame" : {
                                          "x" : 0,
                                          "y" : 505,
                                          "width" : 230,
                                          "height" : 3
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group",
                              "imageType" : "png",
                              "image" : {
                                 "path" : "images/32.png",
                                 "frame" : {
                                    "x" : 0,
                                    "y" : 468,
                                    "width" : 230,
                                    "height" : 40
                                 }
                              }
                           },
                           {
                              "objectId" : "30",
                              "name" : "ArrowDrop",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 206,
                                 "y" : 467,
                                 "width" : 24,
                                 "height" : 24
                              },
                              "children" : [
                                 {
                                    "objectId" : "29",
                                    "name" : "Arrow",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 206,
                                       "y" : 467,
                                       "width" : 24,
                                       "height" : 24
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/29.png",
                                       "frame" : {
                                          "x" : 206,
                                          "y" : 467,
                                          "width" : 24,
                                          "height" : 24
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           },
                           {
                              "objectId" : "28",
                              "name" : "ResidentTab",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 37,
                                 "y" : 506,
                                 "width" : 193,
                                 "height" : 44
                              },
                              "children" : [
                                 {
                                    "objectId" : "27",
                                    "name" : "ResidentBorder",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 37,
                                       "y" : 547,
                                       "width" : 193,
                                       "height" : 3
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/27.png",
                                       "frame" : {
                                          "x" : 37,
                                          "y" : 547,
                                          "width" : 193,
                                          "height" : 3
                                       }
                                    }
                                 },
                                 {
                                    "objectId" : "26",
                                    "name" : "Resident",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 52,
                                       "y" : 506,
                                       "width" : 95,
                                       "height" : 42
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/26.png",
                                       "frame" : {
                                          "x" : 52,
                                          "y" : 506,
                                          "width" : 95,
                                          "height" : 42
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           },
                           {
                              "objectId" : "25",
                              "name" : "TechnicianTab",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 37,
                                 "y" : 548,
                                 "width" : 193,
                                 "height" : 44
                              },
                              "children" : [
                                 {
                                    "objectId" : "24",
                                    "name" : "TechnicianBorder",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 37,
                                       "y" : 589,
                                       "width" : 193,
                                       "height" : 3
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/24.png",
                                       "frame" : {
                                          "x" : 37,
                                          "y" : 589,
                                          "width" : 193,
                                          "height" : 3
                                       }
                                    }
                                 },
                                 {
                                    "objectId" : "23",
                                    "name" : "Technicians",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 52,
                                       "y" : 548,
                                       "width" : 111,
                                       "height" : 42
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/23.png",
                                       "frame" : {
                                          "x" : 52,
                                          "y" : 548,
                                          "width" : 111,
                                          "height" : 42
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           },
                           {
                              "objectId" : "22",
                              "name" : "PoliceTab",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 37,
                                 "y" : 590,
                                 "width" : 193,
                                 "height" : 44
                              },
                              "children" : [
                                 {
                                    "objectId" : "21",
                                    "name" : "PoliceBorder",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 37,
                                       "y" : 631,
                                       "width" : 193,
                                       "height" : 3
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/21.png",
                                       "frame" : {
                                          "x" : 37,
                                          "y" : 631,
                                          "width" : 193,
                                          "height" : 3
                                       }
                                    }
                                 },
                                 {
                                    "objectId" : "20",
                                    "name" : "Police",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 52,
                                       "y" : 590,
                                       "width" : 95,
                                       "height" : 42
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/20.png",
                                       "frame" : {
                                          "x" : 52,
                                          "y" : 590,
                                          "width" : 95,
                                          "height" : 42
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           }
                        ],
                        "kind" : "group"
                     },
                     {
                        "objectId" : "19",
                        "name" : "Infringements",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 647,
                           "width" : 230,
                           "height" : 42
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/19.png",
                           "frame" : {
                              "x" : 0,
                              "y" : 647,
                              "width" : 230,
                              "height" : 42
                           }
                        }
                     },
                     {
                        "objectId" : "18",
                        "name" : "Settings",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 0,
                           "y" : 701,
                           "width" : 230,
                           "height" : 42
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/18.png",
                           "frame" : {
                              "x" : 0,
                              "y" : 701,
                              "width" : 230,
                              "height" : 42
                           }
                        }
                     }
                  ],
                  "kind" : "group"
               },
               {
                  "objectId" : "17",
                  "name" : "AvatarContainer",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 72,
                     "y" : 43,
                     "width" : 106,
                     "height" : 138
                  },
                  "children" : [
                     {
                        "objectId" : "16",
                        "name" : "Avatar_Placeholder",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 72,
                           "y" : 43,
                           "width" : 106,
                           "height" : 106
                        },
                        "children" : [],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/16.png",
                           "frame" : {
                              "x" : 72,
                              "y" : 43,
                              "width" : 106,
                              "height" : 106
                           }
                        }
                     }
                  ],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/17.png",
                     "frame" : {
                        "x" : 72,
                        "y" : 43,
                        "width" : 106,
                        "height" : 138
                     }
                  }
               },
               {
                  "objectId" : "15",
                  "name" : "SignOut",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 72,
                     "y" : 191,
                     "width" : 106,
                     "height" : 24
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/15.png",
                     "frame" : {
                        "x" : 72,
                        "y" : 191,
                        "width" : 106,
                        "height" : 24
                     }
                  }
               },
               {
                  "objectId" : "14",
                  "name" : "Notifications",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 52,
                     "y" : 236,
                     "width" : 178,
                     "height" : 25
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/14.png",
                     "frame" : {
                        "x" : 52,
                        "y" : 236,
                        "width" : 178,
                        "height" : 25
                     }
                  }
               },
               {
                  "objectId" : "13",
                  "name" : "Standard_Chosen",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 452,
                     "width" : 10,
                     "height" : 54
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/13.png",
                     "frame" : {
                        "x" : 0,
                        "y" : 452,
                        "width" : 10,
                        "height" : 54
                     }
                  }
               },
               {
                  "objectId" : "12",
                  "name" : "Inner_Chosen",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 37,
                     "y" : 590,
                     "width" : 10,
                     "height" : 42
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/12.png",
                     "frame" : {
                        "x" : 37,
                        "y" : 590,
                        "width" : 10,
                        "height" : 42
                     }
                  }
               },
               {
                  "objectId" : "11",
                  "name" : "Nav_BG",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 0,
                     "y" : 0,
                     "width" : 250,
                     "height" : 1024
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/11.png",
                     "frame" : {
                        "x" : 0,
                        "y" : 0,
                        "width" : 250,
                        "height" : 1024
                     }
                  }
               }
            ],
            "kind" : "group",
            "imageType" : "png",
            "image" : {
               "path" : "images/46.png",
               "frame" : {
                  "x" : 0,
                  "y" : 0,
                  "width" : 250,
                  "height" : 1024
               }
            }
         },
         {
            "objectId" : "10",
            "name" : "Content",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 290,
               "y" : 40,
               "width" : 1110,
               "height" : 850
            },
            "children" : [
               {
                  "objectId" : "9",
                  "name" : "PoliceMapContainer",
                  "visible" : true,
                  "maskFrame" : {
                     "x" : 290,
                     "y" : 40,
                     "width" : 1110,
                     "height" : 616
                  },
                  "layerFrame" : {
                     "x" : 290,
                     "y" : 40,
                     "width" : 1110,
                     "height" : 616
                  },
                  "children" : [],
                  "kind" : "group"
               },
               {
                  "objectId" : "8",
                  "name" : "PoliceStnName",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 290,
                     "y" : 696,
                     "width" : 690,
                     "height" : 56
                  },
                  "children" : [],
                  "kind" : "group",
                  "imageType" : "png",
                  "image" : {
                     "path" : "images/8.png",
                     "frame" : {
                        "x" : 290,
                        "y" : 696,
                        "width" : 690,
                        "height" : 56
                     }
                  }
               },
               {
                  "objectId" : "7",
                  "name" : "Contact",
                  "visible" : true,
                  "maskFrame" : null,
                  "layerFrame" : {
                     "x" : 290,
                     "y" : 768,
                     "width" : 867,
                     "height" : 122
                  },
                  "children" : [
                     {
                        "objectId" : "6",
                        "name" : "Call_3",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 290,
                           "y" : 768,
                           "width" : 867,
                           "height" : 57
                        },
                        "children" : [
                           {
                              "objectId" : "5",
                              "name" : "Call_2",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 753,
                                 "y" : 768,
                                 "width" : 116,
                                 "height" : 55
                              },
                              "children" : [
                                 {
                                    "objectId" : "4",
                                    "name" : "Call",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 753,
                                       "y" : 768,
                                       "width" : 116,
                                       "height" : 55
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/4.png",
                                       "frame" : {
                                          "x" : 753,
                                          "y" : 768,
                                          "width" : 116,
                                          "height" : 55
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           }
                        ],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/6.png",
                           "frame" : {
                              "x" : 290,
                              "y" : 768,
                              "width" : 867,
                              "height" : 57
                           }
                        }
                     },
                     {
                        "objectId" : "3",
                        "name" : "Email",
                        "visible" : true,
                        "maskFrame" : null,
                        "layerFrame" : {
                           "x" : 290,
                           "y" : 835,
                           "width" : 579,
                           "height" : 55
                        },
                        "children" : [
                           {
                              "objectId" : "2",
                              "name" : "E_mail_2",
                              "visible" : true,
                              "maskFrame" : null,
                              "layerFrame" : {
                                 "x" : 753,
                                 "y" : 835,
                                 "width" : 116,
                                 "height" : 55
                              },
                              "children" : [
                                 {
                                    "objectId" : "1",
                                    "name" : "E_mail",
                                    "visible" : true,
                                    "maskFrame" : null,
                                    "layerFrame" : {
                                       "x" : 753,
                                       "y" : 835,
                                       "width" : 116,
                                       "height" : 55
                                    },
                                    "children" : [],
                                    "kind" : "group",
                                    "imageType" : "png",
                                    "image" : {
                                       "path" : "images/1.png",
                                       "frame" : {
                                          "x" : 753,
                                          "y" : 835,
                                          "width" : 116,
                                          "height" : 55
                                       }
                                    }
                                 }
                              ],
                              "kind" : "group"
                           }
                        ],
                        "kind" : "group",
                        "imageType" : "png",
                        "image" : {
                           "path" : "images/3.png",
                           "frame" : {
                              "x" : 290,
                              "y" : 835,
                              "width" : 579,
                              "height" : 55
                           }
                        }
                     }
                  ],
                  "kind" : "group"
               }
            ],
            "kind" : "group"
         },
         {
            "objectId" : "0",
            "name" : "BG_Back",
            "visible" : true,
            "maskFrame" : null,
            "layerFrame" : {
               "x" : 250,
               "y" : 0,
               "width" : 1190,
               "height" : 1024
            },
            "children" : [],
            "kind" : "group",
            "imageType" : "png",
            "image" : {
               "path" : "images/0.png",
               "frame" : {
                  "x" : 250,
                  "y" : 0,
                  "width" : 1190,
                  "height" : 1024
               }
            }
         }
      ],
      "kind" : "artboard",
      "backgroundColor" : "rgba(1.00000, 1.00000, 1.00000, 1.00000)"
   }
];
